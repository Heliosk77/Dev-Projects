﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Reis_Multiplication
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                /*
                 User inputs 3 different numbers of their choice, program stores them in 
                 the following variables (userInput1, userInput2, and userInput3)
                */
                Console.Write("Enter your first number:");
                double userInput1 = double.Parse((Console.ReadLine()));
                Console.Write("Enter your second number:");
                double userInput2 = double.Parse((Console.ReadLine()));
                Console.Write("Enter your third number:");
                double userInput3 = double.Parse((Console.ReadLine()));
                /*
                Program takes userInput1 & userInput2, and combines them. Then
                takes the output of it and multiplies it by userInput3.
                */
                double output1 = (userInput1 + userInput2);
                double output2 = (output1 * userInput3);
                /*
                Program uses two if statements: if the final result is greater than or equal
                to 100, the program displays the normal output of the earlier formula. If it
                less than 100, the program will just display the first number that the user input.
                */

                if(output2 >= 100)
                {
                    Console.WriteLine("The final result is: " + output2);
                }
                else if(output2 <= 100)
                {
                    Console.WriteLine("The final result is: " + userInput1);                }

                 

            }
            catch(Exception)
            {
                Console.WriteLine("Error, please use valid integers."); 
            }

            {
                Console.ReadKey();
            }
        }
    }
}
