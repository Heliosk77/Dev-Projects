﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
/**********************************
* 
* Project Name: Math
* Author: Keith Reis
* Purpose: Calculate any number problem the user gives the program
* Inputs: userNum
* Outputs: Calculated answer (depends on function user wants to use)
************************************/


namespace Reis_Math
{
    public partial class MathForm : Form
    {
        public MathForm()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //Take text from txtBox1 & convert into double
            double userNum1 = double.Parse(txtNum1.Text);
            //Take text from txtBox2 & convert into double
            double userNum2 = double.Parse(txtNum2.Text);
            //Calculate sum & store it in sum variable
            double sum = userNum1 - userNum2;
            //Display result in rich text box
            txtDisplay.AppendText(userNum1.ToString() + " - " +
                userNum2.ToString() + " = " + sum.ToString() + "\n");
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            //Take text from txtBox1 & convert into double
            double userNum1 = double.Parse(txtNum1.Text);
            //Take text from txtBox2 & convert into double
            double userNum2 = double.Parse(txtNum2.Text);
            //Calculate sum & store it in sum variable
            double sum = userNum1 + userNum2;
            //Display result in rich text box
            txtDisplay.AppendText(userNum1.ToString() + " + " +
                userNum2.ToString() + " = " + sum.ToString() + "\n");
        }

        private void btnMultiply_Click(object sender, EventArgs e)
        {
            //Take text from txtBox1 & convert into double
            double userNum1 = double.Parse(txtNum1.Text);
            //Take text from txtBox2 & convert into double
            double userNum2 = double.Parse(txtNum2.Text);
            //Calculate sum & store it in sum variable
            double sum = userNum1 * userNum2;
            //Display result in rich text box
            txtDisplay.AppendText(userNum1.ToString() + " * " +
                userNum2.ToString() + " = " + sum.ToString() + "\n");
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtNum1.Clear();
            txtNum2.Clear();
        }

        private void sqrButton_Click(object sender, EventArgs e)
        {
            //Take text from txtBox1 & convert into double
            double userNum1 = double.Parse(txtNum1.Text);
            //Take text from txtBox2 & convert into double
            double userNum2 = double.Parse(txtNum2.Text);
            //Calculate sum & store it in sum variable
            double sum = userNum1 * userNum1 + userNum2 * userNum2;
            //Display result in rich text box
            txtDisplay.AppendText(userNum1.ToString() + "^2 + " +
                userNum2.ToString() + "^2 = " + sum.ToString() + "\n");
        }

        private void MathForm_Load(object sender, EventArgs e)
        {

        }
    }
}
