﻿/************************************************
 * Project Name: Tip Tax and Total
 * Author: Keith Reis
 * Purpose: Calculate and display the tip, tax, and total of a meal
 * Inputs: Total cost of a meal
 * Output: Calculated 7% tax and 15% tip along with the total bill with tip and tax included
************************************************/

using System;

namespace Reis_TipTax
{
    class TipTaxTotal
    {
        static void Main(string[] args)
        {
            //Prompt the user to enter in the cost of the meal
            Console.Write("Please enter the pretax and pretip cost of the meal: ");
            //Store the value the user enters in the variable named preTipTaxMealCost
            double preTipTaxMealCost = Double.Parse(Console.ReadLine());
            //Calculate the tax on the meal and store the result in the variable tax
            double tax = preTipTaxMealCost * 0.07;
            //Calculate the tip on the meal and store the result in the variable tip
            double tip = preTipTaxMealCost * 0.15;
            //Calculate the total of the mean inclduing tax and tip
            double total = preTipTaxMealCost + tip + tax;
            //Display the pretax and pretip meal cost
            Console.WriteLine("Meal Cost: " + preTipTaxMealCost.ToString("C"));
            //Display calculated tax.
            Console.WriteLine("Tax: " + tax.ToString("C"));
            //Display calculated 15% tip.
            Console.WriteLine("Tip: " + tip.ToString("C"));
            //Display calculated Total. 
            Console.WriteLine("Total with Tax and Tip: " + total.ToString("C"));
            //Keep the window open
            Console.ReadKey();
        }
    }
}
