﻿/************************************
 * Project Name: MPG
 * Author: Keith Reis
 * Purpose: Calculate the miles per gallon of any vehicle
 * Inputs: Total # of Miles / Total # of Gallons
 * Outputs: Calculated total number of gallons 
************************************/

using System;

namespace Reis_MPG
{
    class Program
    {
        static void Main(string[] args)
        {
            //Display a prompt for the user to enter the total # of gallons their vehicle can hold
            Console.WriteLine("Please enter the total number of gallons your vehicle holds: ");
            //Display a prompt for the user to enter the total # of miles that can be travelled before empty gas tank
            Console.WriteLine("Please enter the total number of miles that can be travelled before the gas tank is empty: ");
            //Store the value the user enters in the variable named totalGallons
            double totalGallons = double.Parse(Console.ReadLine());
            //Store the second value the user enters in the variable named totalMiles
            double totalMiles = double.Parse(Console.ReadLine());
            //Calculate the total MPG by dividing totalGallons by totalMiles
            double total = totalGallons / totalMiles;
            //Display the total MPG 
            Console.WriteLine("Total Miles per Gallon: " + total.ToString("C"));
            Console.ReadKey();
             mbox 
        }
    }
}
