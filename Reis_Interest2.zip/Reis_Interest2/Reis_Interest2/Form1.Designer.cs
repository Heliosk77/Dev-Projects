﻿namespace Reis_Interest2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.SuspendLayout();
            // 
            // Form1
            // 
            this.ClientSize = new System.Drawing.Size(284, 261);
            this.Name = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox UserInput1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox UserInput2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox UserInput3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox UserInput4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox UserInput5;
        private System.Windows.Forms.Button calcButton;
        private System.Windows.Forms.Label label6;
    }
}

