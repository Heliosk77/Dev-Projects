﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Reis_Interest2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {
            //User enters Principal Amt
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {
            //User enters the Total # of Years
        }

        private void label5_Click(object sender, EventArgs e)
        {
            //User enters the amount of interest they hope to earn
        }

        private void calcButton_Click(object sender, EventArgs e)
        {
            //User clicks button, program executes compound interest formula.


        private void txtInterestRate_TextChanged(object sender, EventArgs e)
        {
            //User enters Annual Interest Rate
        }

        private void userBox3_TextChanged(object sender, EventArgs e)
        {
            //User enters the number of times per year to compound the interest
        }

        private void userInput4_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
