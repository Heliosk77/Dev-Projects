﻿/****************************************
Name: Keith Reis
Class: CIS 111
Project: Titanic Analysis
***************************************/


using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Reis_Titanic
{
    public partial class TitanicAnalysisForm : Form
    {
        public TitanicAnalysisForm()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnAnalyze_Click(object sender, EventArgs e)
        {
            //Filters the type of file that can be opened so we can find it 
            //more quickly
            openTitanicData.Filter = "csv files (*.csv)|*.csv|All files (*.*)|*.*";
            //Displays open file dialog window
            if (openTitanicData.ShowDialog() == DialogResult.OK)
            {
                StreamReader inFile;
                inFile = File.OpenText(openTitanicData.FileName);
                int numSurvived = 0;
                int numFirstClass = 0;
                int numThirdClass = 0;
                int numMalePassengers = 0;
                int numFemalePassengers = 0;
                int averageAgeOfSurvivors = 0;
                int averageAgeOfDead = 0;
                double oldestSurvivor = -1;
                double mostExpensiveTicket = -1;
                double youngestSurvivor = 1;
                string oldestSurvivorName = "";
                string mostExpensiveTicketName = "";
                string freeTicketSurvivorName = "";
                string youngestSurvivorName = "";
                inFile.ReadLine();
                //Checks to see if user is at end of file
                while (!inFile.EndOfStream)
                {
                    //Read one line of text
                    string lineOfData = inFile.ReadLine();
                    //Split the line of text at the commas
                    string[] data = lineOfData.Split(',');
                    if (data[0] == "0")
                    {

                    }
                    else if (data[1] == "1")
                    {
                        //If the person survived, and was in first class
                        //add one to the numFirstClass variable
                        numFirstClass = numFirstClass + 1;

                    }
                    else if (data[1] == "3")
                    {
                        //If the person survived, and was in third class
                        //add one to the numThirdClass variable
                        numThirdClass = numThirdClass + 1;
                    }
                    if (data[0] == "1")
                    {
                        //If the person survived, add one to the 
                        //numSurvived variable
                        numSurvived = numSurvived + 1;
                    }
                    //If the person survived, and is the oldest passenger
                    //set the oldestSurvivor variable to that passenger.
                    if (data[0] == "1" && double.Parse(data[4]) > oldestSurvivor)
                    {
                        oldestSurvivor = double.Parse(data[4]);
                        oldestSurvivorName = data[2];
                    }
                    if (data[0] == "1" && double.Parse(data[4]) < youngestSurvivor)
                    {
                        //If the person survived, and is the youngest passenger.
                        //set the youngestSurvivor variable to that passenger.
                        youngestSurvivor = double.Parse(data[4]);
                        youngestSurvivorName = data[2];
                    }

                    if (data[0] == "1" && data[3] == "male")
                    {
                        //If the person is a male and survived, 
                        //add 1 to the numMalePassengers variable.
                        numMalePassengers = numMalePassengers + 1;
                    }
                    if (data[0] == "1" && data[3] == "female")
                    {
                        //If the person is a female and survived,
                        //add 1 to the numFemalePassengers variable.
                        numFemalePassengers = numFemalePassengers + 1;
                    }
                    if (data[0] == "1" && double.Parse(data[7]) > mostExpensiveTicket)
                    {
                        //If the person survived, and purchased the most
                        //expensive ticket, set the mostExpensiveTicket 
                        //variable to that passenger.
                        mostExpensiveTicket = double.Parse(data[7]);
                        mostExpensiveTicketName = data[2];
                        lstTitanicAnalysis.Items.Add("The person who bought the most expensive ticket is " + mostExpensiveTicketName + ", they also survived ");
                    }
                    else if (data[0] == "0" && double.Parse(data[7]) > mostExpensiveTicket)
                    {
                        //If the person did not survive, but still purchased 
                        //the most expensive ticket, set the 
                        //mostExpensiveTicket variable to that passenger.
                        mostExpensiveTicket = double.Parse(data[7]);
                        mostExpensiveTicketName = data[2];
                        lstTitanicAnalysis.Items.Add("The person who bought the most expensive ticket is " + mostExpensiveTicketName + " they did not survive ");
                    }
                    if (data[0] == "1" && data[7] == "0")
                    {
                        //If the person survived, and paid a fare
                        //of 0 pounds. Store their name in the 
                        //freeTicketSurvivorName variable.
                        freeTicketSurvivorName = data[2];
                        
                    }

                }

                lstTitanicAnalysis.Items.Add("Number of survivors = " + numSurvived);
                lstTitanicAnalysis.Items.Add("Number of 1st class passengers = " + numFirstClass);
                lstTitanicAnalysis.Items.Add("Number of 3rd class passengers = " + numThirdClass);
                lstTitanicAnalysis.Items.Add("The oldest passenger to survive is " + oldestSurvivorName);
                lstTitanicAnalysis.Items.Add("The youngest passenger to survive is " + youngestSurvivorName);
                lstTitanicAnalysis.Items.Add("The number of male passengers to survive = " + numMalePassengers);
                lstTitanicAnalysis.Items.Add("The number of female passengers to survive = " + numFemalePassengers);
                lstTitanicAnalysis.Items.Add("Passenger(s) who survived and did not pay any fare to board the Titanic: " + freeTicketSurvivorName);
            }
        }

        private void lstTitanicAnalysis_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
