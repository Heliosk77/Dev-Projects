﻿namespace Reis_Titanic
{
    partial class TitanicAnalysisForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnAnalyze = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.lstTitanicAnalysis = new System.Windows.Forms.ListBox();
            this.openTitanicData = new System.Windows.Forms.OpenFileDialog();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // btnAnalyze
            // 
            this.btnAnalyze.Location = new System.Drawing.Point(423, 376);
            this.btnAnalyze.Name = "btnAnalyze";
            this.btnAnalyze.Size = new System.Drawing.Size(285, 62);
            this.btnAnalyze.TabIndex = 0;
            this.btnAnalyze.Text = "Load and Analyze Data";
            this.btnAnalyze.UseVisualStyleBackColor = true;
            this.btnAnalyze.Click += new System.EventHandler(this.btnAnalyze_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("MS UI Gothic", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(433, 6);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(225, 19);
            this.label1.TabIndex = 1;
            this.label1.Text = "Analysis of Titanic Data";
            // 
            // lstTitanicAnalysis
            // 
            this.lstTitanicAnalysis.FormattingEnabled = true;
            this.lstTitanicAnalysis.Location = new System.Drawing.Point(328, 28);
            this.lstTitanicAnalysis.Name = "lstTitanicAnalysis";
            this.lstTitanicAnalysis.Size = new System.Drawing.Size(450, 329);
            this.lstTitanicAnalysis.TabIndex = 2;
            this.lstTitanicAnalysis.SelectedIndexChanged += new System.EventHandler(this.lstTitanicAnalysis_SelectedIndexChanged);
            // 
            // openTitanicData
            // 
            this.openTitanicData.FileName = "titanic.csv";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Reis_Titanic.Properties.Resources.IcebergMeme2;
            this.pictureBox1.Location = new System.Drawing.Point(12, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(310, 399);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox1.TabIndex = 3;
            this.pictureBox1.TabStop = false;
            // 
            // TitanicAnalysisForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.lstTitanicAnalysis);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnAnalyze);
            this.Name = "TitanicAnalysisForm";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnAnalyze;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ListBox lstTitanicAnalysis;
        private System.Windows.Forms.OpenFileDialog openTitanicData;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}

